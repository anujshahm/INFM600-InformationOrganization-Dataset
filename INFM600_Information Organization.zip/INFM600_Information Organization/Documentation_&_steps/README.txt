﻿Bird strike data set


Link: 
http://www.tableausoftware.com/public/community/sample-data-sets


URL:
http://www.tableau.com/public/community/sample-data-sets#airplane


Questions that can be answered after analysing the data set:
Does the frequency of bird strikes with the aircrafts depend on time such as time of day or season(months)?
Is there any correlation between a particular species of bird/s and type of aircraft/s they strike?


License information:
Source: http://wildlife.faa.gov/


Creative Commons License 
Bird Strikes by Public is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
Based on a work at http://wildlife.faa.gov/.


Citation:
Federal Aviation Administration: Wildlife Strike Database and Reporting System (2011). Airplane Bird Strikes [Data file]. Retrieved from http://www.tableausoftware.com/public/community/sample-data-sets


Link to the Github repository for our data set:
https://github.com/anujshahm/INFM600-InformationOrganization-Dataset


Wiki username/s:
AnujandMagdelana


URL for the wiki page:
http://wiki.urbanhogfarm.com/index.php/Bird_Strikes